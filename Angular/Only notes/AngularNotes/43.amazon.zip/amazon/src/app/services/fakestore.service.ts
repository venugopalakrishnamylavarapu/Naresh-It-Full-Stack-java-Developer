import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FakestoreProductContract } from '../contracts/FakestoreProductContract';

@Injectable()
export class FakestoreService
{
    constructor(private http: HttpClient){

    }
    public GetProduct(id:string):Observable<FakestoreProductContract>{
        return this.http.get<FakestoreProductContract>(`http://fakestoreapi.com/products/${id}`);
    }
    public GetProducts():Observable<FakestoreProductContract[]>{
        return this.http.get<FakestoreProductContract[]>("http://fakestoreapi.com/products");
    }

    public GetCategories():Observable<string[]>{
        return this.http.get<string[]>("http://fakestoreapi.com/products/categories");
    }

    public GetSpecificCategory(categoryName:string):Observable<FakestoreProductContract[]>{
        return this.http.get<FakestoreProductContract[]>(`http://fakestoreapi.com/products/category/${categoryName}`);
    }
}