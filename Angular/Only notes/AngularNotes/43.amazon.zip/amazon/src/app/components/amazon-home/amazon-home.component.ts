import { Component, OnInit } from '@angular/core';
import { FakestoreProductContract } from '../../contracts/FakestoreProductContract'; 
import { FakestoreService } from '../../services/fakestore.service';

@Component({
  selector: 'app-amazon-home',
  templateUrl: './amazon-home.component.html',
  styleUrls: ['./amazon-home.component.css']
})
export class AmazonHomeComponent implements OnInit {
    constructor(private data: FakestoreService){

    }
    public Products:FakestoreProductContract[] = [];
    ngOnInit(){
        this.data.GetProducts().subscribe(data=> this.Products = data);
    }
}
