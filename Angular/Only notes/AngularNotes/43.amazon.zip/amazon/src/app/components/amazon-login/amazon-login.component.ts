import { Component } from '@angular/core';

@Component({
  selector: 'app-amazon-login',
  templateUrl: './amazon-login.component.html',
  styleUrls: ['./amazon-login.component.css']
})
export class AmazonLoginComponent {

}
