import { Component } from '@angular/core';

@Component({
  selector: 'app-amazon-admin',
  templateUrl: './amazon-admin.component.html',
  styleUrls: ['./amazon-admin.component.css']
})
export class AmazonAdminComponent {

}
