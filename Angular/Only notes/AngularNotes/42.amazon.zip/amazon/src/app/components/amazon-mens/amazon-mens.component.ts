import { Component } from '@angular/core';

@Component({
  selector: 'app-amazon-mens',
  templateUrl: './amazon-mens.component.html',
  styleUrls: ['./amazon-mens.component.css']
})
export class AmazonMensComponent {

}
