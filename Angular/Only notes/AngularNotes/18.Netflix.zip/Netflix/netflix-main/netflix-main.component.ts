import { Component } from '@angular/core';

@Component({
  selector: 'app-netflix-main',
  templateUrl: './netflix-main.component.html',
  styleUrls: ['./netflix-main.component.css']
})
export class NetflixMainComponent {

}
