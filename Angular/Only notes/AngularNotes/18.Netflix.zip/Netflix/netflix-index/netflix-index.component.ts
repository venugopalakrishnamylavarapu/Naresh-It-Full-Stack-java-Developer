import { Component } from '@angular/core';

@Component({
  selector: 'app-netflix-index',
  templateUrl: './netflix-index.component.html',
  styleUrls: ['./netflix-index.component.css']
})
export class NetflixIndexComponent {

}
