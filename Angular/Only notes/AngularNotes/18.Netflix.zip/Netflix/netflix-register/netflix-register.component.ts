import { Component } from '@angular/core';

@Component({
  selector: 'app-netflix-register',
  templateUrl: './netflix-register.component.html',
  styleUrls: ['./netflix-register.component.css']
})
export class NetflixRegisterComponent {

}
