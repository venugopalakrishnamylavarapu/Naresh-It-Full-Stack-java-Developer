import { Component } from '@angular/core';

@Component({
  selector: 'app-netflix-header',
  templateUrl: './netflix-header.component.html',
  styleUrls: ['./netflix-header.component.css']
})
export class NetflixHeaderComponent {

}
